(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_@sentry_nextjs_build_esm_index_client_00mxvnu.js","static/chunks/src_app_error_tsx_0ts9uj7._.js"],
    source: "dynamic"
});
