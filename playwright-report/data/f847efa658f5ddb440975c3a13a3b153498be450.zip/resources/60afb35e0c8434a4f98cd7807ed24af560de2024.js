(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/@sentry/nextjs/build/esm/index.client.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_@sentry_nextjs_build_esm_1921blo._.js",
  "static/chunks/node_modules_@sentry_core_build_esm_217wcw-._.js",
  "static/chunks/node_modules_@sentry_browser_build_npm_esm_dev_14ii6yq._.js",
  "static/chunks/node_modules_@sentry_conventions_dist_attributes_mjs_0h46aay._.js",
  "static/chunks/node_modules_@sentry_browser-utils_build_esm_12y4ira._.js",
  "static/chunks/node_modules_@sentry_react_build_esm_0qgn_ki._.js",
  "static/chunks/node_modules_next_0ax500-._.js",
  "static/chunks/node_modules_@sentry_replay_build_npm_esm_index_0j_-05d.js",
  "static/chunks/node_modules_1fv1_pp._.js",
  "static/chunks/node_modules_@sentry_nextjs_build_esm_index_client_18wgpa5.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/@sentry/nextjs/build/esm/index.client.js [app-client] (ecmascript)");
    });
});
}),
]);